BOT_TOKEN = ""  # токен бота
CHANNEL_URL = "https://t.me/"  # Ссылка на канал
CHANNEL_ID = "-100"  # id канала. Начинаеться с минуса
ADMIN_ID =  #tg id твой

REF_URL = ""  # Ссылка на регистрацию
